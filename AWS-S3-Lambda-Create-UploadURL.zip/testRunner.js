const { handler } = require('./index')

const main = async () => {
  await handler()
}

main()

